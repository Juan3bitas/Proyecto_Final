package co.edu.uniquindio.proyectofinal.model;

public class BuilderComida implements BuilderProducto {
    
    private String nombre, descripcion, formaDePreparacion, tamanoPorcion;
    private double precio;

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public void setDescripcion(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    @Override
    public void setFormaDePreparacion(String formaDePreparacion) {
        this.formaDePreparacion = formaDePreparacion;
    }
    @Override
    public void tamanoPorcion(String tamanoPorcion) {
        this.tamanoPorcion = tamanoPorcion;
    }
    
    public Comida getComida(){
        return new Comida(nombre, descripcion, precio, formaDePreparacion, tamanoPorcion);
    }
}
