package co.edu.uniquindio.proyectofinal.model;

public interface Pedido {
    void anadirComidaPedido (Comida comida);
    void eliminarComidaPedido (Comida comida);
    void anadirBebidaPedido (Bebida bebida);
    void eliminarBebidaPedido (Bebida bebida);
}
