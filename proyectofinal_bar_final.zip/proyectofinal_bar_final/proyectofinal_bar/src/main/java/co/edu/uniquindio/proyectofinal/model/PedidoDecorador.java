package co.edu.uniquindio.proyectofinal.model;

import java.util.List;

public abstract class PedidoDecorador implements Pedido {

    private List<Comida> comidas;
    private List<Bebida> bebidas;
    protected Pedido pedido;

    public PedidoDecorador(Pedido pedido){
        this.pedido = pedido;
    }
    
    @Override
    public void eliminarComidaPedido (Comida comida){
        comidas.remove(comida);
    }

    @Override
    public void eliminarBebidaPedido (Bebida bebida){
        bebidas.remove(bebida);
    }

    @Override
    public void anadirComidaPedido(Comida comida) {
        comidas.add(comida);
    }
    
    @Override
    public void anadirBebidaPedido(Bebida bebida) {
        bebidas.add(bebida);
    }
}






