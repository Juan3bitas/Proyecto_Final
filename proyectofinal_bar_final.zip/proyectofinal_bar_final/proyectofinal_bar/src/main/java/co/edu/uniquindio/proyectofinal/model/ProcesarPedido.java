package co.edu.uniquindio.proyectofinal.model;

public abstract class ProcesarPedido {
    public final void procesar() {
        tomarPedido();
        prepararPedido();
        entregarPedido();
    }

    protected abstract void tomarPedido();
    protected abstract void prepararPedido();
    protected abstract void entregarPedido();
}