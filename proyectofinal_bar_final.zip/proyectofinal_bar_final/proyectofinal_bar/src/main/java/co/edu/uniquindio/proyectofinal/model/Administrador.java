package co.edu.uniquindio.proyectofinal.model;

public class Administrador extends Persona {

    public Administrador(String nombre, String identificacion) {
        super(nombre, identificacion);
    }

}
