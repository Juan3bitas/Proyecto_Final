package co.edu.uniquindio.proyectofinal.model;

public interface Empleado {
    double calcularSalario(double salario);
    int getCodigo();
    double getSalario();
}
