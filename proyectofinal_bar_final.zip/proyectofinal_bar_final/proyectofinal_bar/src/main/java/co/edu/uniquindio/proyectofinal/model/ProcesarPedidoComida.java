package co.edu.uniquindio.proyectofinal.model;

public class ProcesarPedidoComida extends ProcesarPedido {
    private Comida comida;

    public ProcesarPedidoComida(Comida comida) {
        this.comida = comida;
    }

    @Override
    protected void tomarPedido() {
        System.out.println("Tomando pedido de comida: " + comida.getNombre());
    }

    @Override
    protected void prepararPedido() {
        System.out.println("Preparando comida: " + comida.getNombre());
    }

    @Override
    protected void entregarPedido() {
        System.out.println("Entregando comida: " + comida.getNombre());
    }
    
}