package co.edu.uniquindio.proyectofinal.model;

public interface Bebida {
    double calcularPrecio(double precio);
    String getNombre();
}
