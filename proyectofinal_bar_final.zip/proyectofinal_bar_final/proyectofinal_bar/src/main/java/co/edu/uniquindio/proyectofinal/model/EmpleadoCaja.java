package co.edu.uniquindio.proyectofinal.model;

public class EmpleadoCaja extends Persona implements Empleado {
    private double salario;
    private int codigo;

    public EmpleadoCaja(String nombre, String identificacion, double salario, int codigo){
        super(nombre, identificacion);
        this.salario = salario;
        assert salario >= 0;
        this.codigo = codigo;
        assert codigo >= 0;
    }
    
    @Override
    public double getSalario(){
        return salario;
    }
    @Override
    public int getCodigo(){
        return codigo;
    }

    @Override
    public double calcularSalario(double salario){
        return salario*1.6;
    }
    
}
