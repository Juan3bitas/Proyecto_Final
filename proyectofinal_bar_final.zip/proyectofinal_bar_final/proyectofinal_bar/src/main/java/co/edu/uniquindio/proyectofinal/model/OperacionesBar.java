package co.edu.uniquindio.proyectofinal.model;

public interface OperacionesBar {
    void anadirEmpleado (Empleado empleado);
    void eliminarEmpleado (Empleado empleado);
}
