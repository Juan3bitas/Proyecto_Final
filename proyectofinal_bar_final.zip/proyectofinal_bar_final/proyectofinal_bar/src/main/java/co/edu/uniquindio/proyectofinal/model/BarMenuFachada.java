package co.edu.uniquindio.proyectofinal.model;

public class BarMenuFachada {
    private MenuBebidas menuBebidas;
    private MenuComidas menuComidas;


    public BarMenuFachada(){
        this.menuBebidas = MenuBebidas.getInstancia();
        this.menuComidas = MenuComidas.getIntancia();
    }

    public void anadirBebidaConAlcohol(String nombre, String descripcion, double precio, double gradoAlcohol) {
        Bebida bebida = new BebidaConAlcohol(nombre, descripcion, precio, gradoAlcohol);
        menuBebidas.anadirBebida(bebida);
    }

    public void anadirBebidaSinAlcohol(String nombre, String descripcion, double precio, double gradoAlcohol) {
        Bebida bebida = new BebidaConAlcohol(nombre, descripcion, precio, gradoAlcohol);
        menuBebidas.anadirBebida(bebida);
    }

    public void eliminarBebida(String nombre) {
        Bebida bebida = menuBebidas.buscarBebidaPorNombre(nombre);
        if (bebida != null) {
            menuBebidas.eliminarBebida(bebida);
        }
    }

    public Bebida buscarBebida(String nombre) {
        return menuBebidas.buscarBebidaPorNombre(nombre);
    }

    
    public void anadirComida(String nombre, double precio) {
        Comida comida = new Comida(nombre, nombre, precio, nombre, nombre);
        menuComidas.anadirComida(comida);
    }

    public void eliminarComida(String nombre) {
        Comida comida = menuComidas.buscarComidaPorNombre(nombre);
        if (comida != null) {
            menuComidas.eliminarComida(comida);
        }
    }

    public Comida buscarComida(String nombre) {
        return menuComidas.buscarComidaPorNombre(nombre);
    }
    
}
