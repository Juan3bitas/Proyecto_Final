package co.edu.uniquindio.proyectofinal.model;

public class FactoryEmpleadoCaja implements FactoryEmpleado {

    @Override
    public Empleado crearEmpleado(){
        return new EmpleadoCaja(null, null, 0, 0);
    }
}
