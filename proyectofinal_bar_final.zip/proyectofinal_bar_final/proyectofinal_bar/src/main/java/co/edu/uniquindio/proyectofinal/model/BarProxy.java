package co.edu.uniquindio.proyectofinal.model;

public class BarProxy implements OperacionesBar {

    private Bar bar;
    private Persona usuario;
    
    public BarProxy(Bar bar, Persona usuario) {
        this.bar = bar;
        this.usuario = usuario;
    }

    @Override
    public void anadirEmpleado(Empleado empleado) {
        if (usuario instanceof Administrador){
            bar.anadirEmpleado(empleado);
        }
        else{
            throw new SecurityException("No tienes permiso para añadir empleado");
        }
    }

    @Override
    public void eliminarEmpleado(Empleado empleado) {
        if (usuario instanceof Administrador){
            bar.eliminarEmpleado(empleado);
        }
        else{
            throw new SecurityException("No tienes permiso para añadir empleado");
        }
    }

    public double calcularDescuento(Producto producto){
        DescuentoStrategy descuentoStrategy;
        if(usuario instanceof Administrador){
            descuentoStrategy = new DescuentoAdminStrategy();
        }
        else if (usuario instanceof Empleado){
            descuentoStrategy = new DescuentoEmpleadoStrategy();
        }
        else{
            throw new IllegalArgumentException("No aplica descuento");
        }
        return producto.getPrecioConDescuento(descuentoStrategy);
    }
}
