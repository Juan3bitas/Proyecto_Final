package co.edu.uniquindio.proyectofinal.model;

import java.util.ArrayList;
import java.util.List;

public class Bar implements OperacionesBar {
    private final String nombre;
    private final MenuBebidas menuBebidas;
    private final MenuComidas menuComidas;
    private List<Empleado> empleados;
    private List<Producto> productos;
    private Administrador admin;

    public Bar(String nombre, MenuBebidas menuBebidas, MenuComidas menuComidas,List<Empleado> empleados, Administrador admin) {
        this.nombre = nombre;
        this.menuBebidas = menuBebidas;
        this.menuComidas = menuComidas;
        this.empleados = new ArrayList<>();
        this.productos  = new ArrayList<>();
        this.admin = admin;
    }

    public String getNombre(){
        return nombre;
    }

    public MenuBebidas getMenuBebidas(){
        return menuBebidas;
    }

    public MenuComidas getMenuComidas(){
        return menuComidas;
    }

    @Override
    public void anadirEmpleado (Empleado empleado){
        if (buscarEmpleadoPorCodigo(empleado.getCodigo())!=null){
            throw new IllegalArgumentException("El empleado ya existe");
        }
        empleados.add(empleado);
    }
    @Override
    public void eliminarEmpleado (Empleado empleado){
        empleados.remove(empleado);
    }
    public Empleado buscarEmpleadoPorCodigo (int codigoBuscado){
        for (Empleado empleado: empleados){
            if(empleado.getCodigo() == codigoBuscado){
                return empleado;
            }
        }
        return null;
    }

    public void anadirProducto (Producto producto){
        productos.add(producto);
    }

    public void eliminarProducto (Producto producto){
        productos.remove(producto);
    }
    public Administrador getAdministrador(){
        return admin;
    }

}