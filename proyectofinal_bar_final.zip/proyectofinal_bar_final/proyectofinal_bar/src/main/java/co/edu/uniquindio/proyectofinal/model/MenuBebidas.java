package co.edu.uniquindio.proyectofinal.model;

import java.util.ArrayList;
import java.util.List;

public class MenuBebidas {
    private static MenuBebidas instancia;
    private List<Bebida> bebidas;

    private MenuBebidas(){
        this.bebidas = new ArrayList<>();
    }

    public void anadirBebida (Bebida bebida){
        bebidas.add(bebida);
    }
    
    public void eliminarBebida (Bebida bebida){
        bebidas.remove(bebida);
    }

    public Bebida buscarBebidaPorNombre (String nombre){
        for (Bebida bebida: bebidas){
            if (bebida.getNombre().equalsIgnoreCase(nombre)){
                return bebida;
            }
        }
        return null;
    }

    public static MenuBebidas getInstancia(){
        if(instancia == null){
            instancia = new MenuBebidas();
        }
        return instancia;
    }
    
}
