package co.edu.uniquindio.proyectofinal.model;

public interface DescuentoStrategy {
    double calcularDescuento(double precio);

}
