package co.edu.uniquindio.proyectofinal.model;

public class EmpleadoMesero extends Persona implements Empleado{
    private double salario;
    private int codigo;

    public EmpleadoMesero(String nombre, String identificacion, double salario, int codigo) {
        super(nombre, identificacion);
        this.salario = salario;
        this.codigo = codigo;
    }

    @Override
    public double getSalario(){
        return salario;
    }
    @Override
    public int getCodigo(){
        return codigo;
    }
    @Override
    public double calcularSalario(double salario){
        return salario;
    }
}
