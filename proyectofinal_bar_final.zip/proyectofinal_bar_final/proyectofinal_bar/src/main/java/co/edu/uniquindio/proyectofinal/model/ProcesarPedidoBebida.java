package co.edu.uniquindio.proyectofinal.model;

public class ProcesarPedidoBebida extends ProcesarPedido {
    private Bebida bebida;

    public ProcesarPedidoBebida(Bebida bebida) {
        this.bebida = bebida;
    }

    @Override
    protected void tomarPedido() {
        System.out.println("Tomando pedido de bebida: " + bebida.getNombre());
    }

    @Override
    protected void prepararPedido() {
        System.out.println("Preparando bebida: " + bebida.getNombre());
    }

    @Override
    protected void entregarPedido() {
        System.out.println("Entregando bebida: " + bebida.getNombre());
    }
}
