package co.edu.uniquindio.proyectofinal.model;

public class BebidaSinAlcohol implements Bebida, Producto{
    private String nombre;
    private String descripcion;
    private double precio;
    private ProductoEstado estado;
    
    public BebidaSinAlcohol(String nombre, String descripcion, double precio) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.estado = new Disponible();
    }

    @Override
    public double calcularPrecio(double precio){
        return precio;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getDescripcion(){
        return descripcion;
    }

    @Override
    public double getPrecioBase(){
        return precio;
    }

    @Override
    public double getPrecioConDescuento(DescuentoStrategy descuentoStrategy) {
        return estado.getPrecioConDescuento(this, descuentoStrategy);
    }

    @Override
    public void setEstado(ProductoEstado estado) {
        this.estado = estado;
    }

    public double getPrecio(){
        return estado.getPrecio(this);
    }
}

