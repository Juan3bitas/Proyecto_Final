package co.edu.uniquindio.proyectofinal.model;

public class FactoryEmpleadoDomiciliario implements FactoryEmpleado{

    @Override
    public Empleado crearEmpleado(){
        return new EmpleadoDomiciliario(null, null, 0, 0);
    }
}
