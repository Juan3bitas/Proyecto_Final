package co.edu.uniquindio.proyectofinal.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import co.edu.uniquindio.proyectofinal.App;
import co.edu.uniquindio.proyectofinal.model.Login;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class IngresarUsuarioController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    List<Login> users= new ArrayList<>();
    
    @FXML
    private TextField userNameField;

    @FXML
    private Label consola;

    @FXML
    void initialize() {
    }
    
    @FXML
    private PasswordField passwordField;

    @FXML
    void loginUser(ActionEvent event) throws IOException {


    users.add(new Login("karen@gmail.com", "Oslito", 1));
    users.add(new Login("karen@gmail.com", "Oslito", 1));
    users.add(new Login("karen@gmail.com", "Oslito", 1));
    users.add(new Login("karen@gmail.com", "Oslito", 1));

    String userName = userNameField.getText();
    String password = passwordField.getText();

    int p= findProfile(userName, password);
    
        if(p==0){
            consola.setText("El usuario no puede ingresar.");
        }else if (p==1){
            
            App.setRoot("secondary");

        
    }

}    

    public int findProfile(String userName, String password) {
        int profile = 0;

        for (Login login : users) {
            if(login.getUserName().equals(userName) && (login.getPassword().equals(password))){ //validar contraseña también
                profile= login.getProfile();
                break;
            }
        }
        return profile;
    }
}
