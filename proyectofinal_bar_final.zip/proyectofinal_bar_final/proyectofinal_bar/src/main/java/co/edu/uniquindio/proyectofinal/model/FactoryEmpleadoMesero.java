package co.edu.uniquindio.proyectofinal.model;

public class FactoryEmpleadoMesero implements FactoryEmpleado{

    @Override
    public Empleado crearEmpleado(){
        return new EmpleadoMesero(null, null, 0, 0);
    }
}
