package co.edu.uniquindio.proyectofinal.model;

public class Agotado implements ProductoEstado {

    @Override
    public double getPrecio(Producto producto) {
        throw new IllegalStateException("El producto está agotado.");
    }

    @Override
    public double getPrecioConDescuento(Producto producto, DescuentoStrategy descuentoStrategy) {
        throw new IllegalStateException("El producto está agotado.");
    }

}
