package co.edu.uniquindio.proyectofinal.model;

public interface FactoryBebida {
    Bebida crearBebida(); 
}