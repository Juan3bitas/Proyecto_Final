package co.edu.uniquindio.proyectofinal.model;

public interface FactoryEmpleado {
    Empleado crearEmpleado();
}
