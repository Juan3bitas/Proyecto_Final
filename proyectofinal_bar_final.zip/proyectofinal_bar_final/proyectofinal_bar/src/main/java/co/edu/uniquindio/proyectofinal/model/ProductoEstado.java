package co.edu.uniquindio.proyectofinal.model;

public interface ProductoEstado {
    double getPrecio (Producto producto);
    double getPrecioConDescuento (Producto producto, DescuentoStrategy descuentoStrategy);
}
