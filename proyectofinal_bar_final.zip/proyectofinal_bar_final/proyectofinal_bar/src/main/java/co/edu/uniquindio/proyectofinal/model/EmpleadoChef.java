package co.edu.uniquindio.proyectofinal.model;

public class EmpleadoChef extends Persona implements Empleado {
    private double salario;
    private int codigo;

    public EmpleadoChef(String nombre, String identificacion, double salario, int codigo) {
        super(nombre, identificacion);
        this.salario = salario;
        this.codigo = codigo;
    }

    public double getSalario(){
        return salario;
    }

    @Override
    public int getCodigo(){
        return codigo;
    }
    @Override
    public double calcularSalario(double salario){
        return salario*1.5;
    }
    
}
