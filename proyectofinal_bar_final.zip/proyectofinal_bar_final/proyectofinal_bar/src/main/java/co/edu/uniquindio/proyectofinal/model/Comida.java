package co.edu.uniquindio.proyectofinal.model;

public class Comida implements Producto {

    private String nombre;
    private String descripcion;
    private double precio;
    private String formaDePreparacion;
    private String tamanoPorcion;
    private ProductoEstado estado;

    public Comida(String nombre, String descripcion, double precio, 
                    String formaDePreparacion, String tamanoPorcion){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.formaDePreparacion = formaDePreparacion;
        this.tamanoPorcion = tamanoPorcion;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public double getPrecioBase(){
        return precio;
    }

    public String getFormaDePreparacion(){
        return formaDePreparacion;
    }

    public String getTamanoPorcion(){
        return tamanoPorcion;
    }
    
    @Override
    public double getPrecioConDescuento (DescuentoStrategy descuentoStrategy){
        return estado.getPrecioConDescuento(this, descuentoStrategy);

    }

    @Override
    public void setEstado(ProductoEstado estado) {
      this.estado = estado;  
    }

    public double getPrecio(){
        return estado.getPrecio(this);
    }
}
