package co.edu.uniquindio.proyectofinal.model;

public class FactoryBebidaSinAlcohol implements FactoryBebida {
    
    @Override
    public Bebida crearBebida(){
        return new BebidaSinAlcohol(null, null, 0);
    }
}
