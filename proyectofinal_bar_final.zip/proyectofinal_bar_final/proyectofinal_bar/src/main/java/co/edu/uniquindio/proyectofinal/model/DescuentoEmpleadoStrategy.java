package co.edu.uniquindio.proyectofinal.model;

public class DescuentoEmpleadoStrategy implements DescuentoStrategy {

    @Override
    public double calcularDescuento(double precio) {
        return precio * 0.85;
        
    }

}
