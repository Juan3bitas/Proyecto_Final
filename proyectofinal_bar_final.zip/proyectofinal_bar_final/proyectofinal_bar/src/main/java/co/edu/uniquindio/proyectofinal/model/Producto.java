package co.edu.uniquindio.proyectofinal.model;

public interface Producto {
    String getNombre();
    String getDescripcion();
    double getPrecioBase();
    double getPrecioConDescuento(DescuentoStrategy descuentoStrategy);
    void setEstado(ProductoEstado estado);
}
