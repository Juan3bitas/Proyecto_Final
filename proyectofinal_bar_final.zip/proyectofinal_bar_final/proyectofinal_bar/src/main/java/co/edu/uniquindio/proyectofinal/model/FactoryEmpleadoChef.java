package co.edu.uniquindio.proyectofinal.model;

public class FactoryEmpleadoChef implements FactoryEmpleado{

    @Override
    public Empleado crearEmpleado(){
        return new EmpleadoChef(null, null, 0, 0);
    }
}
