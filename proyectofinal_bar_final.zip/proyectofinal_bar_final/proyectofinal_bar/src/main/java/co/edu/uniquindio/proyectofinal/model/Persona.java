package co.edu.uniquindio.proyectofinal.model;

public abstract class Persona {

    private String nombre, identificacion;

    public Persona(String nombre, String identificacion) {
        this.nombre = nombre;
        this.identificacion = identificacion;
    }
    
    public String getNombre(){
        return nombre;
    }

    public String getIdentificacion(){ 
        return identificacion;
    }
}