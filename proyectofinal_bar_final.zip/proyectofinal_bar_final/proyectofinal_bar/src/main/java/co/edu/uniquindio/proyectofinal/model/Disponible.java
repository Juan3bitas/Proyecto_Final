package co.edu.uniquindio.proyectofinal.model;

public class Disponible implements ProductoEstado {

    @Override
    public double getPrecio(Producto producto) {
        return producto.getPrecioBase();
    }

    @Override
    public double getPrecioConDescuento(Producto producto, DescuentoStrategy descuentoStrategy) {
        return descuentoStrategy.calcularDescuento(producto.getPrecioBase());
    }

}
