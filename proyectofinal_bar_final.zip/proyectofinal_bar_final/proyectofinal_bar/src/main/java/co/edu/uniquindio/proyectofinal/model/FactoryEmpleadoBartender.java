package co.edu.uniquindio.proyectofinal.model;

public class FactoryEmpleadoBartender implements FactoryEmpleado{

    @Override
    public Empleado crearEmpleado(){
        return new EmpleadoBartender(null, null, 0, 0);
    }
}
