package co.edu.uniquindio.proyectofinal.model;

public interface BuilderProducto {
    
    void setNombre(String nombre);
    void setDescripcion(String descripcion);
    void setPrecio(double precio);
    void setFormaDePreparacion(String formaDePreparacion);
    void tamanoPorcion(String tamanoPorcion);
}