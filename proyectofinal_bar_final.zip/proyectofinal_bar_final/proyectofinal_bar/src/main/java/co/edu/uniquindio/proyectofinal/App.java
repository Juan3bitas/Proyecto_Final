package co.edu.uniquindio.proyectofinal;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * JavaFX App
 */
public class App extends Application {

    List<Login> users= new Arraylist<>();

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {



        users.add(new Login("karen@gmail.com", "Oslito", 1));
        users.add(new Login("karen@gmail.com", "Oslito", 1));
        users.add(new Login("karen@gmail.com", "Oslito", 1));
        users.add(new Login("karen@gmail.com", "Oslito", 1));




        int p= findProfile("karen@gmail.com", "Oslito");
        if(p==0){
            System.out.printLn("No puede iniciar sesión")
        }else if(p==1){
            scene = new Scene(loadFXML("primary"), 640, 480);
            stage
            stage.setScene(scene);
            stage.show();
        }else{
            scene = new Scene(loadFXML("secundary"), 640, 480);
            stage
            stage.setScene(scene);
            stage.show();
        }

    }

    public int findProfile(String userName, String password) {
        int profile = 0;
        foreach(Login user: users){
            if(user.getUserName().equals(userName) ){ //validar contraseña también
                profile=user.getProfile();
                break;
            }
        }
        return profile;
    }

     public static void closeWindow() {
        Stage stage = (Stage) scene.getWindow();
        stage.close();
    }


    public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}