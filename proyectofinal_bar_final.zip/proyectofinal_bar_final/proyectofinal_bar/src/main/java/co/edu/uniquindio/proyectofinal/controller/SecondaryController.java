package co.edu.uniquindio.proyectofinal.controller;

import co.edu.uniquindio.proyectofinal.model.Comida;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn;

public class SecondaryController{

    @FXML
    void initialize() {

        comidas = FXCollections.observableArrayList();

        comidas.add(new Comida("Arroz", "Frío", 2.000, "xd", "personal"));
        tablaProd.setItems(comidas);
    }

    //ArrayList que contiene los productos que se ven en la tabla
    ObservableList<Comida> comidas;

    @FXML
    private Button aniadirProd;
    
    @FXML
    private Button eliminarProd;

    @FXML
    private Button modificarProd;

    @FXML
    private Button nuevoProd;

    @FXML
    private TextField txProducto;

    @FXML
    private TextField txDescripcion;

    @FXML
    private TextField txPrecio;

    @FXML
    private TextField txTamano;

    @FXML
    private TextField txPreparacion;

    @FXML
    private TableView<Comida> tablaProd;

    //Muestra datos de tipo String, y está asociada a un modelo de datos tipo Producto
    @FXML
    private TableColumn<Comida, String> nombreProd;

    @FXML
    private TableColumn<Comida, String> descripcionProd;

    @FXML
    private TableColumn<Comida, String> precioProd;

    @FXML
    private TableColumn<Comida, String> tamanoProd;

    @FXML
    private TableColumn<Comida, String> preparacionProd;


    

    //Cuando se pongan todos los datos, se añaden a la tabla;
    @FXML
    private void aniadirProd (ActionEvent event) {
       //Obtenemos los datos del campo de texto

       String nombre = txProducto.getText();
       String descripcion = txDescripcion.getText();
       String preparacion = txPreparacion.getText();
       String tamanoPorcion = txTamano.getText();
       double precio = Double.parseDouble(txPrecio.getText());

       //se crea la instancia de Comida con los datos

       Comida comida = new Comida(nombre, descripcion, precio, preparacion, tamanoPorcion);
       comidas.add(comida);

       tablaProd.setItems(comidas);
       tablaProd.refresh();
      

    }

    @FXML
    private void eliminarProd (ActionEvent event) {

        int posicionProductoEnTabla = tablaProd.getSelectionModel().getSelectedIndex();
        if (posicionProductoEnTabla >= 0) {
            comidas.remove(posicionProductoEnTabla);
        } else {
            System.out.println("Selccione un producto que desee eliminar");

        }
    
    }

    @FXML
    private void modificarProd (ActionEvent event) {

        //Se obtiene un indice, al seleccionar un producto
        int posicionProductoEnTabla = tablaProd.getSelectionModel().getSelectedIndex();

        //Verificamos si hay algun item seleccionado
        if (posicionProductoEnTabla >= 0) {

            Comida comidaSeleccionada = tablaProd.getItems().get(posicionProductoEnTabla);

            comidaSeleccionada.setNombre(txProducto.getText());
            comidaSeleccionada.setDescripcion(txDescripcion.getText());
            comidaSeleccionada.setFormaDePreparacion(txPreparacion.getText());
            comidaSeleccionada.setPrecio(Double.parseDouble(txPrecio.getText()));

            tablaProd.refresh();

        } else {

            System.out.println("Seleccione un producto para su modificación");

        }    
    }

    //Introducir nuevo producto
    @FXML
    private void nuevoProd (ActionEvent event) {

        txProducto.setText("");
        txDescripcion.setText(" ");
        txPrecio.setText(" ");
        txTamano.setText(" ");
        txPreparacion.setText("");
        //No se pueden presionar los otros botones
        modificarProd.setDisable(true);
        eliminarProd.setDisable(true);
        aniadirProd.setDisable(false); //Cuando se ingresen los datos, se añada el producto
    
    }


    public static void main(String[] args) {
        
    }

}