package co.edu.uniquindio.proyectofinal.model;

import java.util.List;

public class PedidoConBolsa extends PedidoDecorador{
    public boolean tieneBolsa;
    public String colorBolsa;
    public List<Comida> comidas;
    public List<Bebida> bebidas;

    public PedidoConBolsa(Pedido pedido, boolean tieneBolsa, String colorBolsa) {
        super(pedido);
        this.tieneBolsa = tieneBolsa;
        this.colorBolsa = colorBolsa;
        
    }
    
    @Override
    public void eliminarComidaPedido (Comida comida){
        comidas.remove(comida);
    }

    @Override
    public void eliminarBebidaPedido (Bebida bebida){
        bebidas.remove(bebida);
    }

    @Override
    public void anadirComidaPedido(Comida comida) {
        comidas.add(comida);
    }

    @Override
    public void anadirBebidaPedido(Bebida bebida) {
        bebidas.add(bebida);
    }

    public boolean isTieneBolsa() {
        return tieneBolsa;
    }

    public void setTieneBolsa(boolean tieneBolsa) {
        this.tieneBolsa = tieneBolsa;
    }

    public String getColorBolsa() {
        return colorBolsa;
    }

    public void setColorBolsa(String colorBolsa) {
        this.colorBolsa = colorBolsa;
    }
}


