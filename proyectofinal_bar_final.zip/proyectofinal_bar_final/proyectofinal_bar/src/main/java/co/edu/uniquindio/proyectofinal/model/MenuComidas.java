package co.edu.uniquindio.proyectofinal.model;

import java.util.ArrayList;
import java.util.List;

public class MenuComidas {
    private static MenuComidas instancia;
    private List<Comida> comidas;

    private MenuComidas(){
        this.comidas = new ArrayList<>();
    }

    public void anadirComida (Comida comida){
        comidas.add(comida);
    }

    public void eliminarComida (Comida comida){
        comidas.remove(comida);
    }
    
    public Comida buscarComidaPorNombre (String nombre){
        for (Comida comida: comidas){
            if (comida.getNombre().equalsIgnoreCase(nombre)){
                return comida;
            }
        }
        return null;
    }
    
    public static MenuComidas getIntancia(){
        if(instancia == null){
            instancia = new MenuComidas();
        }
        return instancia;
    }
}
