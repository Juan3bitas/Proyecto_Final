package co.edu.uniquindio.proyectofinal.model;

public class Login {

    private String userName;
    private String password;
    private int profile;

    public Login(String userName, String password, int profile){
        this.userName=userName;
        this.password=password;
        this.profile=profile;
    }

    
}