package co.edu.uniquindio.proyectofinal.model;

public class BebidaConAlcohol implements Bebida, Producto{
    private String nombre;
    private String descripcion;
    private Double precio;
    private double gradoAlcohol;
    private ProductoEstado estado;
    
    public BebidaConAlcohol(String nombre, String descripcion, double precio, double gradoAlcohol) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.gradoAlcohol = gradoAlcohol;
        this.estado = new Disponible();
    }

    @Override
    public double calcularPrecio(double precio){
        return precio+(gradoAlcohol*precio);
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public double getPrecioBase(){
        return precio;
    }
    
    @Override
    public double getPrecioConDescuento (DescuentoStrategy descuentoStrategy){
        return estado.getPrecioConDescuento(this, descuentoStrategy);
    }

    @Override
    public void setEstado(ProductoEstado estado) {
        this.estado=estado;
    }
    public double getPrecio(){
        return estado.getPrecio(this);
    }
}
