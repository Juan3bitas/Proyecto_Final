package co.edu.uniquindio.proyectofinal.model;

public class FactoryBebidaConAlcohol implements FactoryBebida{

    @Override
    public Bebida crearBebida(){
        return new BebidaConAlcohol(null, null, 0, 0);
    }
}